# Test Plan

## 1. Objective
Automatically verify that the critical flows of an e-commerce demo application (saucedemo.com) and a REST API (JSONPlaceholder) work as expected.

## 2. Scope
| In scope | Out of scope |
|---|---|
| Login (positive/negative), cart, checkout flow | Performance/load testing (would be done separately with JMeter or k6) |
| API: GET/POST/PUT/DELETE, schema, filtering, 404 | Security penetration testing |

## 3. Test Approach
- **Test pyramid:** many fast API tests plus a small number of critical end-to-end UI tests.
- **Techniques:** equivalence partitioning, boundary values (parametrized), negative testing, state transitions.
- **Design:** Page Object Model, fixtures for reuse, `smoke` / `negative` markers.
- **Tools:** Python, pytest, Playwright, requests, pytest-html, GitHub Actions.

## 4. Entry / Exit Criteria
- Entry: the environment is reachable and dependencies are installed.
- Exit: all `smoke` tests pass and no Blocker/Critical defect is open.

## 5. Risks
The third-party demo sites can change or become temporarily unavailable. The weekly scheduled CI run is how I catch that early.
