# Manual Test Cases (Samples)

| ID | Title | Precondition | Steps | Expected Result | Priority | Automated by |
|---|---|---|---|---|---|---|
| TC-01 | Valid login | User exists | Log in with standard_user / secret_sauce | Product list page opens | High | test_valid_login |
| TC-02 | Wrong password | - | Enter a wrong password | "do not match" error is shown | High | test_invalid_login_shows_error |
| TC-03 | Locked-out user | - | Log in as locked_out_user | "locked out" error is shown | Medium | test_invalid_login_shows_error |
| TC-04 | Add item to cart | Logged in | Add the backpack | Cart badge shows 1 | High | test_add_to_cart_updates_badge |
| TC-05 | Complete an order | Cart has an item | Checkout, fill in details, Finish | "Thank you for your order!" | Critical | test_full_checkout_flow |
| TC-06 | Required field check | Cart has an item | Leave first name empty | "First Name is required" | Medium | test_checkout_requires_first_name |
| TC-07 | Unauthorized page access | Not logged in | Open /inventory.html directly | Access is blocked and an error is shown | High | test_protected_page_requires_login |
| TC-08 | API: nonexistent record | - | GET /posts/99999 | 404 | Medium | test_get_nonexistent_post_returns_404 |
