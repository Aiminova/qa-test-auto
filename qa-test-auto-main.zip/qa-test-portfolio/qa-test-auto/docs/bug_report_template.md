# Bug Report Template

**Title:** [Module] Short, clear summary
**Environment:** Browser/version, OS, application version
**Severity:** Blocker / Critical / Major / Minor / Trivial
**Priority:** P1 / P2 / P3

**Steps to reproduce:**
1. ...
2. ...

**Actual result:** ...
**Expected result:** ...
**Attachments:** screenshot, video, logs, HAR file

---
## Example
**Title:** [Checkout] No error message when first name is left empty
**Severity:** Major | **Priority:** P2
**Steps:** 1) Log in 2) Add an item 3) Checkout 4) Leave first name empty, click Continue
**Actual:** Nothing happens  **Expected:** "First Name is required"
