"""UI tests - cart and checkout (end-to-end purchase flow)."""
import pytest
from playwright.sync_api import Page, expect
from pages.saucedemo import LoginPage, InventoryPage, CheckoutPage

pytestmark = pytest.mark.ui


@pytest.fixture
def logged_in(page: Page):
    login = LoginPage(page)
    login.open()
    login.login("standard_user", "secret_sauce")
    return page


def test_inventory_shows_six_products(logged_in):
    assert InventoryPage(logged_in).items.count() == 6


def test_add_to_cart_updates_badge(logged_in):
    inv = InventoryPage(logged_in)
    inv.add_backpack()
    expect(inv.cart_badge).to_have_text("1")


@pytest.mark.smoke
def test_full_checkout_flow(logged_in):
    inv = InventoryPage(logged_in)
    inv.add_backpack()
    inv.open_cart()
    logged_in.click("#checkout")
    checkout = CheckoutPage(logged_in)
    checkout.fill_info("Alex", "Morgan", "10001")
    checkout.finish()
    expect(checkout.confirmation).to_have_text("Thank you for your order!")


@pytest.mark.negative
def test_checkout_requires_first_name(logged_in):
    InventoryPage(logged_in).add_backpack()
    logged_in.click(".shopping_cart_link")
    logged_in.click("#checkout")
    CheckoutPage(logged_in).fill_info("", "Morgan", "10001")
    expect(logged_in.locator("[data-test='error']")).to_contain_text("First Name is required")
