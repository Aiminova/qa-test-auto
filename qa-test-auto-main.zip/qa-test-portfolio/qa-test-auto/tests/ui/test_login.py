"""UI tests - login. Application under test: saucedemo.com (a demo store built for testing)."""
import pytest
from playwright.sync_api import Page, expect
from pages.saucedemo import LoginPage

pytestmark = pytest.mark.ui


@pytest.mark.smoke
def test_valid_login(page: Page):
    login = LoginPage(page)
    login.open()
    login.login("standard_user", "secret_sauce")
    expect(page).to_have_url("https://www.saucedemo.com/inventory.html")


@pytest.mark.negative
@pytest.mark.parametrize(
    "user,pwd,message",
    [
        ("standard_user", "wrong_password", "Username and password do not match"),
        ("locked_out_user", "secret_sauce", "locked out"),
        ("", "secret_sauce", "Username is required"),
        ("standard_user", "", "Password is required"),
    ],
)
def test_invalid_login_shows_error(page: Page, user, pwd, message):
    login = LoginPage(page)
    login.open()
    login.login(user, pwd)
    expect(login.error).to_contain_text(message)


@pytest.mark.negative
def test_protected_page_requires_login(page: Page):
    page.goto("/inventory.html")
    expect(page.locator("[data-test='error']")).to_contain_text("only access")
