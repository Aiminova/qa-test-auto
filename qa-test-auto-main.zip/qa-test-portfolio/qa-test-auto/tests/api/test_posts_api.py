"""API tests against JSONPlaceholder (a public fake REST API).
Coverage: status codes, response schema, data correctness, filtering, CRUD,
negative scenario, boundary IDs and response time."""
import pytest

pytestmark = pytest.mark.api


def url(api, path):
    return f"{api.base_url}{path}"


@pytest.mark.smoke
def test_get_all_posts_returns_100(api):
    r = api.get(url(api, "/posts"))
    assert r.status_code == 200
    assert len(r.json()) == 100


@pytest.mark.smoke
def test_get_single_post_schema_and_values(api):
    r = api.get(url(api, "/posts/1"))
    body = r.json()
    assert r.status_code == 200
    assert set(body) == {"userId", "id", "title", "body"}
    assert body["id"] == 1 and body["userId"] == 1
    assert isinstance(body["title"], str) and body["title"]


def test_filter_posts_by_user(api):
    r = api.get(url(api, "/posts"), params={"userId": 1})
    posts = r.json()
    assert r.status_code == 200
    assert len(posts) == 10
    assert all(p["userId"] == 1 for p in posts)


def test_create_post(api):
    payload = {"title": "QA test", "body": "content", "userId": 1}
    r = api.post(url(api, "/posts"), json=payload)
    body = r.json()
    assert r.status_code == 201
    assert body["title"] == payload["title"]
    assert "id" in body


def test_update_post(api):
    payload = {"id": 1, "title": "updated", "body": "new body", "userId": 1}
    r = api.put(url(api, "/posts/1"), json=payload)
    assert r.status_code == 200
    assert r.json()["title"] == "updated"


def test_delete_post(api):
    r = api.delete(url(api, "/posts/1"))
    assert r.status_code == 200


@pytest.mark.negative
def test_get_nonexistent_post_returns_404(api):
    r = api.get(url(api, "/posts/99999"))
    assert r.status_code == 404


@pytest.mark.parametrize("post_id", [1, 25, 50, 100])
def test_posts_boundary_ids(api, post_id):
    r = api.get(url(api, f"/posts/{post_id}"))
    assert r.status_code == 200
    assert r.json()["id"] == post_id


def test_response_time_under_2_seconds(api):
    r = api.get(url(api, "/posts"))
    assert r.elapsed.total_seconds() < 2


def test_content_type_is_json(api):
    r = api.get(url(api, "/users"))
    assert "application/json" in r.headers["Content-Type"]
    assert len(r.json()) == 10
