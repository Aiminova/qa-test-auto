"""Page Object Model: each page class owns its locators and actions.
If the UI changes, only this file needs an update and the tests stay untouched."""
from playwright.sync_api import Page


class LoginPage:
    def __init__(self, page: Page):
        self.page = page

    def open(self):
        self.page.goto("/")

    def login(self, username: str, password: str):
        self.page.fill("#user-name", username)
        self.page.fill("#password", password)
        self.page.click("#login-button")

    @property
    def error(self):
        return self.page.locator("[data-test='error']")


class InventoryPage:
    def __init__(self, page: Page):
        self.page = page

    @property
    def items(self):
        return self.page.locator(".inventory_item")

    @property
    def cart_badge(self):
        return self.page.locator(".shopping_cart_badge")

    def add_backpack(self):
        self.page.click("#add-to-cart-sauce-labs-backpack")

    def open_cart(self):
        self.page.click(".shopping_cart_link")


class CheckoutPage:
    def __init__(self, page: Page):
        self.page = page

    def fill_info(self, first: str, last: str, postal: str):
        self.page.fill("#first-name", first)
        self.page.fill("#last-name", last)
        self.page.fill("#postal-code", postal)
        self.page.click("#continue")

    def finish(self):
        self.page.click("#finish")

    @property
    def confirmation(self):
        return self.page.locator(".complete-header")
